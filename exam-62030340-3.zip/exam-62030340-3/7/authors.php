<?php
$arr_Author_1 = array("authorID"=>1111,"author"=>"sittipon", "penname"=>"บ้านหนองหญ้าปล้อง");
$arr_Author_2 = array("authorID"=>1112,"author"=>"chinno", "penname"=>"A ต้องมาแล้วครับ");
$arr_Author_3 = array("authorID"=>1113,"author"=>"tharadon", "penname"=>"ชาบูก็หิวโปรเจ็คก็ต้องทำ");
$ARR_Author = array($arr_Author_1,$arr_Author_2,$arr_Author_3);
// [ { "authorID"=>1111, "author"=>"Wittawas", "penname"=>"witty100" }, ... , ...}]
echo json_encode($ARR_Author);
?>