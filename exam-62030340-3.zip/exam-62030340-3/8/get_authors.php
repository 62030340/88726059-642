<?php
require_once("../server.php");

if ($_GET) {
    $get_Value_Authors = "%{$_GET['get_Value_Authors']}%";
}
else {
    $get_Value_Authors = "%"; } 

    $sql = "SELECT *
    FROM author
    WHERE authorID  LIKE ? 
    ORDER BY authorID ASC";


    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $get_Value_Authors);
    $stmt->execute();
    $result = $stmt->get_result();

    $authorsrow = array();
    if ($result->num_rows > 0) {
        while ($authorsrow = $result->fetch_object()) {
            $authors_row_arr[] = $authorsrow;
        }
    }
    
    echo json_encode($authors_row_arr);



?>
